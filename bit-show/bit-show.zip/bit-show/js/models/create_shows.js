// creating shows

class Creatshows {
    constructor(id, img, showName, rating) {
      this.id = id;
      this.img = img;
      this.showName = showName;
      this.rating = rating;
    };
  };
  
  